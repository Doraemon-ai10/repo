# WebHero Cinematic WebGL

This package is a browser-playable 3D superhero prototype optimized for desktop and touch devices.

## Run as a real web game
Use any static web host or local server. Recommended local test:

`python3 -m http.server 8080`

Then open `http://localhost:8080/`.

Do not rely on opening the files with `file://`; ES modules are more reliable through HTTP(S).

## Controls
PC: WASD, Space, Shift, hold E/left mouse for web, right mouse to rotate camera.
Mobile: joystick, WEB, JUMP, HIT.

## Visual/gameplay focus
- ACES filmic tone mapping
- bloom and soft shadows
- atmospheric fog
- layered original 3D hero
- large procedural city
- landmark tower and bridge
- crowd NPCs
- multi-layer web cable
- mobile-friendly renderer settings

This is an original superhero prototype, not an official Spider-Man game and does not include copyrighted Spider-Man assets.
